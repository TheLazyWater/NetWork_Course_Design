#include "readonlydelegate.h"
